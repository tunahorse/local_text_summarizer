# Text Summarizer

A Python package for simple local text summarization with nltk.

## Installation

```
pip install local_text_summarizer
```

## Usage

```
summarize "Your text here"
```
